import csv
import random
from itertools import combinations

# Define the fixed list of items (ensuring deterministic behavior)
items = ["Milk", "Bread", "Eggs", "Diapers", "Soap", "Shampoo", "Towel", "Juice", "Cereal", "Cheese"]

# Seed the random number generator for repeatability
random.seed(2020)

# Save the items list into a file
items_file = "items.csv"
with open(items_file, "w", newline="") as f:
    writer = csv.writer(f)
    for item in items:
        writer.writerow([item])

# Function to read the items list from a file
def read_items(file_path):
    with open(file_path, "r") as f:
        return [line.strip() for line in f if line.strip()]

# Function to generate a random number of items per transaction (between 3 and 8)
def get_random_count():
    return random.randint(3, 8)

# Function to generate a set of transactions
def generate_transactions(item_list, num_transactions=20):
    transactions = []
    for _ in range(num_transactions):
        num_items = get_random_count()
        transaction = random.sample(item_list, num_items)
        transactions.append(sorted(transaction))  # Sorting to ensure deterministic order
    return transactions

# Function to save transactions into a CSV file
def save_transactions(transactions, file_path):
    with open(file_path, "w", newline="") as f:
        writer = csv.writer(f)
        for transaction in transactions:
            writer.writerow(transaction)

# Load the items from the saved file
loaded_items = read_items(items_file)

# Generate and save 5 transaction datasets
for i in range(1, 6):
    transactions = generate_transactions(loaded_items)
    save_transactions(transactions, f"data{i}.csv")

print("Data generation complete. Files generated: items.csv, data1.csv, data2.csv, data3.csv, data4.csv, data5.csv")